//
//  CollectViewCell.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DuWenImageView.h"

@interface CollectViewCell : UITableViewCell
@property(nonatomic,strong)UILabel *titileLabel;
@property(nonatomic,strong)DuWenImageView *picImageView;
@end
