//
//  DuWenShowViewController.h
//  BaseProject
//
//  Created by soft on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DuWenShowViewController : UIViewController
@property(nonatomic,assign)NSInteger type;
@property(nonatomic,assign)NSInteger oldTimestamp;
@end
