//
//  CollectModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "CollectModel.h"

@implementation CollectModel

@end
