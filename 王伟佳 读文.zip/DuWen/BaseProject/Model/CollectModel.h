//
//  CollectModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface CollectModel : BaseModel

@property (nonatomic,strong) NSString *newsPicURL;
@property (nonatomic,strong) NSString *newsTitle;
@property (nonatomic,strong) NSString *newsURL;

@end
